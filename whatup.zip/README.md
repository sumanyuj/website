# -GIT--Personal-Website


This is a the code repo for my personal website project hosted on the web. (sumanyuj.com)


Most of the interactivity of the website is with me, in items like my resume, blog, and plugs.
